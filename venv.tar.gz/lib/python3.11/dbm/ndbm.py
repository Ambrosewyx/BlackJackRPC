"""Provide the _dbm module as a dbm submodule."""

from _dbm import *
